USE softprog;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE linea_orden_venta;
TRUNCATE TABLE orden_venta;
TRUNCATE TABLE producto;
TRUNCATE TABLE cliente;
TRUNCATE TABLE empleado;
TRUNCATE TABLE cuenta_usuario;
TRUNCATE TABLE area;

SET FOREIGN_KEY_CHECKS = 1;

-- =========================
-- area
-- =========================
INSERT INTO area (id, nombre, activo) VALUES
(1, 'Ventas', TRUE),
(2, 'Recursos Humanos', TRUE),
(3, 'Almacen', TRUE),
(4, 'Finanzas', TRUE),
(5, 'Sistemas', TRUE),
(6, 'Atencion al Cliente', TRUE);

-- =========================
-- cuenta_usuario
-- =========================
INSERT INTO cuenta_usuario (id, user_name, password, activo) VALUES
(1,  'administrador',            'admin123', TRUE),
(2,  'mquiroz@softprog.pe',      'clave123', TRUE),
(3,  'rvaldez@softprog.pe',      'clave123', TRUE),
(4,  'lparedes@softprog.pe',     'clave123', TRUE),
(5,  'cmontes@softprog.pe',      'clave123', TRUE),
(6,  'agomez@softprog.pe',       'clave123', TRUE),
(7,  'jtorres@softprog.pe',      'clave123', TRUE),
(8,  'pmedina@softprog.pe',      'clave123', TRUE),
(9,  'frojas@softprog.pe',       'clave123', TRUE),
(10, 'ecastillo@softprog.pe',    'clave123', TRUE),
(11, 'vramirez@softprog.pe',     'clave123', TRUE),
(12, 'snunez@softprog.pe',       'clave123', TRUE),
(13, 'dsalazar@softprog.pe',     'clave123', TRUE);

-- =========================
-- empleado
-- =========================
INSERT INTO empleado (
    id, id_area, id_cuenta_usuario, dni, nombre, apellido_paterno,
    genero, fecha_nacimiento, cargo, sueldo, activo
) VALUES
(1, 1, 2, '45678912', 'Martin', 'Quiroz',   'MASCULINO', '1990-03-15', 'VENDEDOR_SENIOR',        3200.00, TRUE),
(2, 1, 3, '50123456', 'Rosa',   'Valdez',   'FEMENINO',  '1993-07-20', 'EJECUTIVO_COMERCIAL',    2900.00, TRUE),
(3, 2, 4, '47890123', 'Lucia',  'Paredes',  'FEMENINO',  '1988-11-02', 'ANALISTA_RRHH',          3400.00, TRUE),
(4, 3, 5, '48901234', 'Carlos', 'Montes',   'MASCULINO', '1991-01-28', 'ENCARGADO_ALMACEN',      3000.00, TRUE),
(5, 4, 6, '46789012', 'Andrea', 'Gomez',    'FEMENINO',  '1987-06-10', 'CONTADOR',               3800.00, TRUE),
(6, 5, 7, '51234567', 'Jorge',  'Torres',   'MASCULINO', '1994-09-18', 'TECNICO',                4200.00, TRUE);

-- =========================
-- cliente
-- =========================
INSERT INTO cliente (
    id, id_cuenta_usuario, dni, nombre, apellido_paterno,
    genero, fecha_nacimiento, categoria, linea_credito, activo
) VALUES
(1,  8,  '73456789', 'Patricia', 'Medina',   'FEMENINO',  '1995-04-11', 'ORO',     9745.71, TRUE),  -- 10000.00 - orden 254.29
(2,  9,  '74567890', 'Felipe',   'Rojas',    'MASCULINO', '1992-12-05', 'PLATA',   4841.88, TRUE),  -- 5000.00 - orden 158.12
(3, 10,  '75678901', 'Elena',    'Castillo', 'FEMENINO',  '1989-08-23', 'BRONCE',  1099.98, TRUE),  -- 1500.00 - orden 400.02
(4, 11,  '76789012', 'Victor',   'Ramirez',  'MASCULINO', '1990-02-14', 'ORO',     9910.32, TRUE),  -- 10000.00 - orden 89.68
(5, 12,  '77890123', 'Sofia',    'Nunez',    'FEMENINO',  '1998-10-30', 'PLATA',   4859.58, TRUE),  -- 5000.00 - orden 140.42
(6, 13,  '78901234', 'Diego',    'Salazar',  'MASCULINO', '1996-05-09', 'BRONCE',  1081.45, TRUE);  -- 1500.00 - orden 418.55

-- =========================
-- producto
-- =========================
INSERT INTO producto (id, nombre, unidad_medida, precio, activo) VALUES
(1, 'Cuaderno A4',             'UND', 12.50,  TRUE),
(2, 'Lapiz HB',                'UND', 7.00,   TRUE),
(3, 'Mochila Ejecutiva',       'UND', 45.00,  TRUE),
(4, 'Archivador Oficio',       'UND', 18.00,  TRUE),
(5, 'Calculadora Cientifica',  'UND', 88.00,  TRUE),
(6, 'Resaltador Amarillo',     'UND', 26.00,  TRUE),
(7, 'Impresora Multifuncional','UND', 249.90, TRUE),
(8, 'Mouse Inalambrico',       'UND', 34.80,  TRUE);

-- =========================
-- orden_venta
-- =========================
INSERT INTO orden_venta (id, id_cliente, id_empleado, total, activo) VALUES
(1, 1, 1, 254.29, TRUE),  -- subtotal 215.50 + IGV 38.79
(2, 2, 2, 158.12, TRUE),  -- subtotal 134.00 + IGV 24.12
(3, 3, 1, 400.02, TRUE),  -- subtotal 339.00 + IGV 61.02
(4, 4, 2, 89.68,  TRUE),  -- subtotal 76.00 + IGV 13.68
(5, 5, 1, 140.42, TRUE),  -- subtotal 119.00 + IGV 21.42
(6, 6, 2, 418.55, TRUE);  -- subtotal 354.70 + IGV 63.85

-- =========================
-- linea_orden_venta
-- =========================
INSERT INTO linea_orden_venta (id, id_orden_venta, id_producto, cantidad, sub_total, activo) VALUES
-- Orden 1
(1,  1, 1, 3,  37.50, TRUE),
(2,  1, 3, 2,  90.00, TRUE),
(3,  1, 5, 1,  88.00, TRUE),

-- Orden 2
(4,  2, 2, 4,  28.00, TRUE),
(5,  2, 4, 3,  54.00, TRUE),
(6,  2, 6, 2,  52.00, TRUE),

-- Orden 3
(7,  3, 7, 1, 249.90, TRUE),
(8,  3, 8, 2,  69.60, TRUE),
(9,  3, 1, 1,  12.50, TRUE),
(10, 3, 2, 1,   7.00, TRUE),

-- Orden 4
(11, 4, 4, 2,  36.00, TRUE),
(12, 4, 6, 1,  26.00, TRUE),
(13, 4, 2, 2,  14.00, TRUE),

-- Orden 5
(14, 5, 1, 2,  25.00, TRUE),
(15, 5, 6, 2,  52.00, TRUE),
(16, 5, 2, 6,  42.00, TRUE),

-- Orden 6
(17, 6, 7, 1, 249.90, TRUE),
(18, 6, 2, 10, 70.00, TRUE),
(19, 6, 8, 1,  34.80, TRUE);
